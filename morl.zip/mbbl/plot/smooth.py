# -*- coding:utf-8 -*-
import pandas as pd
import numpy as np
import os
import csv
def smooth(csv_path,weight=0.85): #weight是平滑度，tensorboard 默认0.6
    data = pd.read_csv(filepath_or_buffer=csv_path,header=0,names=['Step','Value'],dtype={'Step':np.int,'Value':np.float})
    scalar = data['Value'].values
    last = scalar[0]
    smoothed = []
    for point in scalar:
        smoothed_val = last * weight + (1 - weight) * point
        smoothed.append(smoothed_val)
        last = smoothed_val


    save = pd.DataFrame({'Step':data['Step'].values,'Value':smoothed})
    save.to_csv('smooth_'+csv_path)

def save():
    xr=[]
    yr=[]
    dr=[]
    new=[]
    with open('../tests/result/ra/9ppo2021-09-07-10:59:38.csv') as csvfile:
        plots = csv.reader(csvfile, delimiter=',')
        for row in plots:
            if float(row[0]) not in new:
                new.append(float(row[0]))
                xr.append(float(row[2]))  # 将第一列数据添加到x列表 Wall time,Step,Value
                yr.append(float(row[3]))  # 将第二列数据添加到y列表
                dr.append([float(row[0]),float(row[2]), float(row[3])])
            else:
                continue
    return dr


def fourSum(nums, target):
    """
    :type nums: List[int]
    :type target: int
    :rtype: List[List[int]]
    """
    nums.sort()
    n = len(nums)
    if n < 4: return []
    out = []
    a = 0
    while a < n - 3 and nums[a] <= target:
        b = a + 1
        while b < n - 2:
            c = b + 1
            d = n - 1
            while c < d:
                if nums[a] + nums[b] + nums[c] + nums[d] == target:
                    if [nums[a], nums[b], nums[c], nums[d]] not in out:
                        out.append([nums[a], nums[b], nums[c], nums[d]])
                        c += 1
                        d -= 1
                elif nums[a] + nums[b] + nums[c] + nums[d] < target:
                    c += 1
                else:
                    d -= 1
            b += 1
        a += 1
    return out


if __name__=='__main__':
    #smooth('mf12.csv')
    dr=fourSum([1,-2,-5,-4,-3,3,3,5],-11)
    print(dr)

