# -*- coding:utf-8 -*-
import numpy as np
from matplotlib import pyplot as plt
import csv
from mbbl.util.common.hypervolume import HVCalculator
xr=[]
yr=[]
dr=[]
xp=[]
yp=[]
dp=[]
xc=[]
yc=[]
dc=[]
# 打开文件
'''
with open ('smooth_MBMF1.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        x.append(int(row[1]))  #将第一列数据添加到x列表 Wall time,Step,Value
        y0.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_MBMF12.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y1.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_MBMF123.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y2.append(float(row[2]))  #将第二列数据添加到y列表
'''
with open ('../result1/ra/9ppo2022-04-21-23:38:58.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        xr.append(float(row[2]))  # 将第一列数据添加到x列表 Wall time,Step,Value
        yr.append(float(row[3]))  #将第二列数据添加到y列表
        dr.append([float(row[2]),float(row[3])])

ref=[0.,0.]
hr=HVCalculator.get_volume_from_array(dr, ref)
print('RA:hypervolume = {:.0f}, solutions = {:.0f}'.format(hr, len(dr)))

with open ('../result1/pfa/9ppo2022-04-22-00:11:58.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        xp.append(float(row[2]))
        yp.append(float(row[3]))  #将第二列数据添加到y列表
        dp.append([float(row[2]), float(row[3])])

hp = HVCalculator.get_volume_from_array(dp, ref)
print('PFA:hypervolume = {:.0f}, solutions = {:.0f}'.format(hp, len(dp)))


with open ('../result1/cem/9reppo2022-04-22-09:08:17.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        xc.append(float(row[2]))
        yc.append(float(row[3]))  # 将第二列数据添加到y列表
        dc.append([float(row[2]), float(row[3])])

hc = HVCalculator.get_volume_from_array(dc, ref)
print('CEM:hypervolume = {:.0f}, solutions = {:.0f}'.format(hc, len(dc)))
'''
with open ('smooth_MEMF123.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y6.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_MEMF1234.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y7.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_rs1.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y10.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_rs12.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y11.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_rs123.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y12.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_rs1234.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y13.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_mf1.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y14.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_mf12.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y15.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_mf123.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y16.append(float(row[2]))  #将第二列数据添加到y列表

with open ('smooth_mf1234.csv') as csvfile:
    plots = csv.reader(csvfile, delimiter=',')
    for row in plots:
        y17.append(float(row[2]))  #将第二列数据添加到y列表

plt.subplot(221)
plt.plot(x, y10, label='RS')#
plt.plot(x, y14, label='PPO')#
plt.plot(x, y0, label='MBMF')#,linestyle='--'
plt.plot(x, y4, label='MESPPO')#
plt.xlabel('timestep')
plt.ylabel('reward')
plt.title('Seed=9')
plt.legend()

plt.subplot(222)
plt.plot(x, y11, label='RS')#
plt.plot(x, y15, label='PPO')#
plt.plot(x, y1, label='MBMF')#,c='green',linestyle='--'
plt.plot(x, y5, label='MESPPO')#
plt.xlabel('timestep')
plt.ylabel('reward')
plt.title('Seed=12')
plt.legend()
'''
#plt.subplot(121)
#plt.plot(x, y12, label='RS')#
#plt.plot(x, y16, label='PPO')#
#plt.plot(x, y2, label='MBMF')#c='orange',linestyle='-.',linewidth=2,linestyle='--'
#plt.plot(x, y6, label='MESPPO')#,linestyle=':',linewidth=3\
#plt.xlabel('object1')
#plt.ylabel('object2')
#plt.title('Pareto Front')
#plt.legend()
#plt.subplot(122)

#plt.figure(1)
plt.subplot(221)
plt.plot(xr[:], yr[:], 'ob',label='RA')
plt.xlabel('object1')
plt.ylabel('object2')
plt.title('Pareto Frontier')
plt.legend()
#plt.figure(2)
plt.subplot(222)
plt.plot(xp[:], yp[:], 'ro',label='PFA')
plt.xlabel('object1')
plt.ylabel('object2')
plt.title('Pareto Frontier')
plt.legend()
#plt.figure(3)
plt.subplot(223)
plt.plot(xc[:], yc[:], 'go',label='OURS')
#plt.plot(x, y17, label='PPO')#
#plt.plot(x, y3, label='MBMF')#c='red',linestyle='--'
#plt.plot(x, y7, label='Ours')#linestyle=':',linewidth=3
plt.xlabel('object1')
plt.ylabel('object2')
plt.title('Pareto Frontier')
plt.legend()
plt.subplot(224)
#plt.figure(4)
plt.plot(xr[:], yr[:], 'ob',linewidth=1,label='RA')
plt.plot(xp[:], yp[:], 'ro',linewidth=1,label='PFA')
plt.plot(xc[:], yc[:], 'go',linewidth=1,label='OURS')
plt.xlabel('object1')
plt.ylabel('object2')
plt.title('SEED=9')
plt.legend()
plt.show()
