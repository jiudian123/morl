import logging #日志模块 logging库提供了多个组件：Logger、Handler、Filter、Formatter。
# Logger对象提供应用程序可直接使用的接口，Handler发送日志到适当的目的地，Filter提供了过滤日志信息的方法，Formatter指定日志显示格式。
import sys
import os
import datetime
from termcolor import colored  # 标注文本颜色

__all__ = ['set_file_handler']  # the actual worker is the '_logger'
# 其他文件用“from 模块名 import *”的形式导入该logger模块时，只能使用 __all__ 列表中指定的成员。

#python中向文件导入某个模块时，导入的是该模块中那些名称不以下划线（单下划线“_”或者双下划线“__”）开头的变量、函数和类，
# 如果不想模块文件中的某个成员被引入到其它文件中使用，可以在其名称前添加下划线。
class _MyFormatter(logging.Formatter):  # 定义format格式
    '''
        @brief:
            a class to make sure the format could be used
    '''

    def format(self, record):
        date = colored('[%(asctime)s @%(filename)s:%(lineno)d]', 'green')
        msg = '%(message)s'

        if record.levelno == logging.WARNING:
            fmt = date + ' ' + \
                colored('WRN', 'red', attrs=[]) + ' ' + msg
        elif record.levelno == logging.ERROR or \
                record.levelno == logging.CRITICAL:
            fmt = date + ' ' + \
                colored('ERR', 'red', attrs=['underline']) + ' ' + msg
        else:
            fmt = date + ' ' + msg

        if hasattr(self, '_style'):   # hasattr() 函数用于判断对象是否包含对应的属性。
            # Python3 compatibilty
            self._style._fmt = fmt
        self._fmt = fmt

        return super(self.__class__, self).format(record)


_logger = logging.getLogger('joint_embedding')  #初始化日志，命名为joint—embedding
_logger.propagate = False  #防止日志记录向上层logger传递。
_logger.setLevel(logging.INFO) # 等级设为info，只有日志等级大于或等于才输出，日志级别等级CRITICAL > ERROR > WARNING > INFO > DEBUG > NOTSET

# set the console output handler
con_handler = logging.StreamHandler(sys.stdout)  # 日志信息会输出到指定的stream（终端）中
#stream指定将日志的输出流，可以指定输出到sys.stderr,sys.stdout或者文件，默认输出到sys.stderr，当stream和filename同时指定时，stream被忽略
con_handler.setFormatter(_MyFormatter(datefmt='%m%d %H:%M:%S')) #日志输出格式
_logger.addHandler(con_handler) # haddler添加到logger


class GLOBAL_PATH(object):

    def __init__(self, path=None):
        if path is None:
            path = os.getcwd() #当前工作目录。
        self.path = path

    def _set_path(self, path):
        self.path = path

    def _get_path(self):
        return self.path


PATH = GLOBAL_PATH()


def set_file_handler(path=None, prefix='', time_str=''):
    # set the file output handler

    if time_str == '':
        file_name = prefix + \
            datetime.datetime.now().strftime("%A_%d_%B_%Y_%I:%M%p") + '.log'
    else:
        file_name = prefix + time_str + '.log'  # 文件名

    if path is None:
        mod = sys.modules['__main__']  # sys.modules是一个全局字典，导入新的模块时，sys.modules都将自动记录这些模块。
        path = os.path.join(os.path.abspath(mod.__file__), '..', '..', 'log') # 绝对路径，获取地址
    else:
        path = os.path.join(path, 'log')
    path = os.path.abspath(path)  # 获取绝对路径 ：home/zhu/mbbl/log

    path = os.path.join(path, file_name) # 加上文件名：home/zhu/mbbl/log/xxx.log
    if not os.path.exists(path):
        os.makedirs(path)   # 没有就创建

    PATH._set_path(path)
    path = os.path.join(path, file_name) # 再加文件名 ：home/zhu/mbbl/log/xxx.log/xxx.log
    from tensorboard_logger import configure
    configure(path) #将一个文件写入到path，文件会在每次写入事件后刷新。：home/zhu/mbbl/log/xxx.log/xxx.log

    file_handler = logging.FileHandler(
        filename=os.path.join(path, 'logger'), encoding='utf-8', mode='w') #文件handler ：home/zhu/mbbl/log/xxx.log/xxx.log/logger
    file_handler.setFormatter(_MyFormatter(datefmt='%m%d %H:%M:%S'))  # 配置格式
    _logger.addHandler(file_handler)  # 为logger添加filehandler

    _logger.info('Log file set to {}'.format(path)) # info信息
    return path


def _get_path():
    return PATH._get_path()


_LOGGING_METHOD = ['info', 'warning', 'error', 'critical',
                   'warn', 'exception', 'debug']

# export logger functions
for func in _LOGGING_METHOD:
    locals()[func] = getattr(_logger, func) #  locals()以字典类型返回当前位置的全部局部变量。getattr() 函数用于返回一个对象属性值。
