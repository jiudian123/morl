# -----------------------------------------------------------------------------
#   @brief: save the true datapoints into a buffer
#   @author: Tingwu Wang
# -----------------------------------------------------------------------------
import numpy as np


class replay_buffer(object):

    def __init__(self, use_buffer, buffer_size, rand_seed,
                 observation_size, action_size, save_reward=False):

        self._use_buffer = use_buffer
        self._buffer_size = buffer_size
        self._npr = np.random.RandomState(rand_seed)

        if not self._use_buffer: # 是否使用buffer
            self._buffer_size = 0

        self._observation_size = observation_size  # 观测维度
        self._action_size = action_size  # 动作维度

        reward_data_size = self._buffer_size if save_reward else 0  # 奖励=buffersize
        self._data = {  # 数据格式：状态、下一个状态、动作、奖励
            'start_state': np.zeros(
                [self._buffer_size, self._observation_size],
                dtype=np.float16
            ),#buffer行，size列

            'end_state': np.zeros(
                [self._buffer_size, self._observation_size],
                dtype=np.float16
            ),

            'action': np.zeros(
                [self._buffer_size, self._action_size],
                dtype=np.float16
            ),

            'reward': np.zeros([reward_data_size], dtype=np.float16)
        }
        self._data_key = [key for key in self._data if len(self._data[key]) > 0] # key =[start_state,end_state,action,reward]

        self._current_id = 0
        self._occupied_size = 0

    def add_data(self, new_data):
        if self._buffer_size == 0:
            return

        num_new_data = len(new_data['start_state'])

        if num_new_data + self._current_id > self._buffer_size:  # 超出容量
            num_after_full = num_new_data + self._current_id - self._buffer_size  # 记下多出来的数据
            for key in self._data_key:
                # filling the tail part 先填满后边
                self._data[key][self._current_id: self._buffer_size] = \
                    new_data[key][0: self._buffer_size - self._current_id]

                # filling the head part  再替换前边
                self._data[key][0: num_after_full] = \
                    new_data[key][self._buffer_size - self._current_id:]

        else:

            for key in self._data_key:
                self._data[key][self._current_id:
                                self._current_id + num_new_data] = \
                    new_data[key]

        self._current_id = \
            (self._current_id + num_new_data) % self._buffer_size  # 当前所在位置
        self._occupied_size = \
            min(self._buffer_size, self._occupied_size + num_new_data) #已用容量

    def get_data(self, batch_size):

        # the data from old data
        sample_id = self._npr.randint(0, self._occupied_size, batch_size)  # 从已用容量中随机选数据
        return {key: self._data[key][sample_id] for key in self._data_key}

    def get_current_size(self):
        return self._occupied_size

    def get_all_data(self):
        return {key: self._data[key][:self._occupied_size]
                for key in self._data_key}
