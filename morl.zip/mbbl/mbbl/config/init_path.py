import os.path as osp
import datetime

real_file_path = osp.realpath(__file__.replace('pyc', 'py'))  # 获取当前执行脚本的绝对路径，将其中pyc替换成py
# /home/zhu/mbbl/mbbl/config/init_path.py
_this_dir = osp.dirname(real_file_path)  # 去掉文件名，返回目录。/home/zhu/mbbl/mbbl/config

running_start_time = datetime.datetime.now()
time = str(running_start_time.strftime("%Y-%m-%d-%X"))  # 2020-11-27-15:21:32

_base_dir = osp.join(_this_dir, '..', '..')  # /home/zhu/mbbl/mbbl/config/../..


def bypass_frost_warning():
    return 0


def get_base_dir():
    return _base_dir


def get_time():
    return time


def get_abs_base_dir():
    return osp.abspath(_base_dir)  # 返回绝对路径/home/zhu/mbbl
