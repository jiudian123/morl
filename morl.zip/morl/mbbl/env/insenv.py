# -*- coding:utf-8 -*-
import random

import os
import numpy as np

from mbbl.config import init_path
from mbbl.env import base_env_wrapper
from mbbl.env import env_register
from mbbl.env import env_util
import gym
from gym import spaces
from gym.utils import seeding


class env(base_env_wrapper.base_env):
    def __init__(self, env_name, rand_seed, misc_info):
        super(env, self).__init__(env_name, rand_seed, misc_info)
        self._base_path = init_path.get_abs_base_dir()
        self.min_action = 0.
        self.max_action = 1.0
        self.min_v = 10.
        self.max_v = 200.
        self.c1 = 5.
        self.c2 = 120.
        self.c3 = 0.
        self.v = 10.
        self.s = 0.
        self.sf=150.
        #self.weight=weight1



        self.low_state = np.array(
            [0.,0.,0.,self.min_v], dtype=np.float32
        )
        self.high_state = np.array(
            [20.,200.,110.,self.max_v], dtype=np.float32
        )

        self.action_space = spaces.Box(
            low=self.min_action,
            high=self.max_action,
            shape=(1,),
            dtype=np.float32
        )
        self.observation_space =  spaces.Box(
            low=self.low_state,
            high=self.high_state,
            dtype=np.float32
        )

        self.seed()
        self.reset()

    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

    def step(self, action):

        c1 = self.state[0]
        c2 = self.state[1]
        c3 =self.state[2]
        v=self.state[3]

        input = (min(max(action[0], self.min_action), self.max_action))*0.2#[0]
        self._current_step += 1
        #if c2 == 0:
         #   c2 = 150

        #zeta = 0.408*c2/((1+c3/16)*(0.22+c2))
        #tao = c2/((1+c3/71.5)*(0.44+c2))

        #dc1 = zeta*c1-(c1/v)*input
        #dc2 = -10*zeta*c1+((150-c2)/v)*input
        #dc3 = tao*c1-(c3/v)*input
        #dv = input

        dc1=0.28*(1-c1/17.75)*(1/(1+c2/102.1))-input*c1/v #细菌
        dc3=0.46*dc1+0.18*(c2/(c2+12.2))*(1/(1+c2/41.5))*c1-input*c3/v #产物
        dc2 = -dc1/0.51-dc3/0.61-0.04 * c1+input * (self.sf-c2) / v # 低物
        dv=input

        c1 += dc1
        c2 += dc2
        c3 += dc3
        v += dv

        done = bool(
            v > self.max_v or c2 < 0
            or self._current_step > self._env_info['max_length']
        )

        reward1 = c3*v
        #if v==10:
        #    reward2=0
        #else:
        self.s += dv*self.sf
        #reward2 = 50-self.s*0.005
        reward2=(c3*v)/(self.s+1200-c2*v)*500

        self.state = np.array([c1,c2,c3,v])

        #if c2<0:
        #    self.state = np.array([c1, 0, c3, v])

        #reward = self.weight*reward1+(1-self.weight)*reward2
        reward=0
        return self.state, reward, done, {'obj':np.around([reward1,reward2], decimals=2)}


    def reset(self):
        self.state = np.array([5.,120.,0.,10.])
        self.s = 0.
        self._current_step=0
        return self.state

    def render(self, mode='human'):
       pass

    def _build_env(self):
        _env_name = {'insenv': 'Insenv-v0'}
        self._env = gym.make(_env_name[self._env_name])
        self._env_info = env_register.get_env_info(self._env_name)


if __name__ == "__main__":

    env=env('insenv', 0, {'allow_monitor': 0})
    obs = env.reset()
    done=0

    count=0

    while not done:
        action=[1,0]

        obs, reward, done, info = env.step(action)
        count += 1
        print( count,obs ,info)