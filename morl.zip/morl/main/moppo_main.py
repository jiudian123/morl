import os
import numpy as np
import multiprocessing
import time
from collections import OrderedDict
import tensorflow as tf
from mbbl.config import base_config
from mbbl.config import init_path
from mbbl.config import mf_config
from mbbl.util.base_main import make_sampler, make_trainer, log_results
from mbbl.util.common import logger
from mbbl.util.common import parallel_util
from mbbl.util.common.hypervolume import compute_fitness, generate_weights,HVCalculator



def train(trainer, sampler, worker, dynamics, policy, reward, objw ,pareto,args=None,):
    logger.info('Training starts at {}'.format(init_path.get_abs_base_dir()))
    network_type = {'policy': policy, 'dynamics': dynamics, 'reward': reward}

    # make the trainer and sampler

    sampler_agent = make_sampler(sampler, worker, network_type, objw, args)
    trainer_tasks, trainer_results, trainer_agent, init_weights = \
        make_trainer(trainer, network_type, args)
    sampler_agent.set_weights(init_weights)

    timer_dict = OrderedDict()
    timer_dict['Program Start'] = time.time()
    current_iteration = 0
    plist = []
    flist= []
    ref = [0., 0.]

    while True:
        timer_dict['** Program Total Time **'] = time.time()

        # step 1: collect rollout data
        rollout_data = \
            sampler_agent.rollouts_using_worker_playing(use_true_env=True)

        timer_dict['Generate Rollout'] = time.time()

        # step 2: train the weights for dynamics and policy network
        training_info = {'network_to_train':['policy'] }#['dynamics', 'reward', 'policy']
        trainer_tasks.put(
            (parallel_util.TRAIN_SIGNAL,
             {'data': rollout_data['data'], 'training_info': training_info})
        )
        trainer_tasks.join()
        training_return = trainer_results.get()

        timer_dict['Train Weights'] = time.time()
        dominate=1
        if current_iteration == 0:
            dominate = 0
            plist.append(training_return['bestobject'])
            flist.append(compute_fitness(training_return['bestobject'],objw))
        else:
            for lenth in range(len(plist),0,-1):
                if training_return['bestobject'][0] > plist[lenth-1][0] \
                    and training_return['bestobject'][1] > plist[lenth-1][1]:
                    del plist[lenth-1]
                    del flist[lenth-1]
                elif training_return['bestobject'][0]<= plist[lenth-1][0] \
                     and training_return['bestobject'][1] <= plist[lenth-1][1]:
                    dominate=0
                    break

        if dominate:
            plist.append(training_return['bestobject'])
            flist.append(compute_fitness(training_return['bestobject'], objw))

        #phv=compute_hv(preobject)
        #if hv>0.8*phv:
        sampler_agent.set_weights(training_return['network_weights'])
        #else:
        #    sampler_agent.set_weights(preparms)
        timer_dict['Assign Weights'] = time.time()

        # log and print the results
        log_results(training_return, timer_dict)

        # if totalsteps > args.max_timesteps:
        if training_return['totalsteps'] > args.max_timesteps:
            break
        elif args.method == 'pfa' and training_return['totalsteps']%10000==0:
            if training_return['totalsteps']<=10000:
                nobjw=objw
            hvol = HVCalculator.get_volume_from_array(plist, ref)
            print(nobjw)
            ppoint = {'weight': nobjw,
                      'objects': plist,
                      'fitness':flist,
                      'hypervolume': np.around([hvol], decimals=2)
                      # 'netweights':training_return['network_weights']['policy']
                      }  # {weight:[0.1 0.9],'objects': plist[]}
            pareto.put(ppoint)
            sampler_agent.end()
            ratio=training_return['totalsteps']/args.max_timesteps
            ratio = np.clip(ratio, 0.0, 1.0)
            w = np.clip(objw[0] + ratio * 0.1, 0.1, 0.9)
            nobjw=np.array([abs(w), abs(1.0 - w)])
            sampler_agent = make_sampler(sampler, worker, network_type, nobjw, args)
            sampler_agent.set_weights(training_return['network_weights'])
            #preparms = training_return['network_weights']
            #preobject = training_return['bestobject']
        else:
            current_iteration += 1

    hvol = HVCalculator.get_volume_from_array(plist, ref)
    ppoint = {'weight': objw,
              'objects': plist,
              'fitness': flist,
              'hypervolume': np.around([hvol],decimals=2)
               #'netweights':training_return['network_weights']['policy']
             }#{weight:[0.1 0.9],'objects': plist[]}
    pareto.put(ppoint)
    # end of training
    sampler_agent.end()
    trainer_tasks.put((parallel_util.END_SIGNAL, None))
    return  training_return['network_weights']['policy'][0]

def re_train(policy_weight,trainer,sampler, worker, dynamics,policy,reward,objw ,pareto,args=None):
    logger.info('Training starts at {}'.format(init_path.get_abs_base_dir()))
    network_type = {'policy': policy, 'dynamics': dynamics, 'reward': reward}

    sampler_agent = make_sampler(sampler, worker, network_type, objw, args)
    trainer_tasks, trainer_results, trainer_agent, init_weights = \
        make_trainer(trainer, network_type, args)

    trainer_tasks.put((parallel_util.SET_POLICY_WEIGHT, policy_weight))  # =66
    trainer_tasks.join()
    init_weights['policy'][0]= policy_weight # 附初始化权重
    sampler_agent.set_weights(init_weights)

    timer_dict = OrderedDict()
    timer_dict['Program Start'] = time.time()
    current_iteration = 0
    plist = []
    flist = []
    ref = [0., 0.]
    while True:
        timer_dict['** Program Total Time **'] = time.time()

            # step 1: collect rollout data
        rollout_data = \
            sampler_agent.rollouts_using_worker_playing(use_true_env=True)

        timer_dict['Generate Rollout'] = time.time()

            # step 2: train the weights for dynamics and policy network
        training_info = {'network_to_train': ['policy']}  # ['dynamics', 'reward', 'policy']
        trainer_tasks.put(  # 写队列
            (parallel_util.TRAIN_SIGNAL,  # =1
             {'data': rollout_data['data'], 'training_info': training_info})
        )
        trainer_tasks.join()
        training_return = trainer_results.get()
        timer_dict['Train Weights'] = time.time()
        dominate = 1
        if current_iteration == 0:
            dominate = 0
            plist.append(training_return['bestobject'])
            flist.append(compute_fitness(training_return['bestobject'], objw))
        else:
            for lenth in range(len(plist), 0, -1):
                if training_return['bestobject'][0] > plist[lenth - 1][0] \
                        and training_return['bestobject'][1] > plist[lenth - 1][1]:
                    del plist[lenth - 1]
                    del flist[lenth-1]
                elif training_return['bestobject'][0] <= plist[lenth - 1][0] \
                        and training_return['bestobject'][1] <= plist[lenth - 1][1]:
                    dominate = 0
                    break

        if dominate:
            plist.append(training_return['bestobject'])
            flist.append(compute_fitness(training_return['bestobject'], objw))

        sampler_agent.set_weights(training_return['network_weights'])
            # else:
            #    sampler_agent.set_weights(preparms)
        timer_dict['Assign Weights'] = time.time()

            # log and print the results
        log_results(training_return, timer_dict)

            # if totalsteps > args.max_timesteps:
        if training_return['totalsteps'] > args.max_timesteps:
            break
        else:
          current_iteration += 1


    hvol = HVCalculator.get_volume_from_array(plist, ref)
    ppoint = {'weight': objw,
              'objects': plist,
              'fitness': flist,
              'hypervolume': np.around([hvol], decimals=2)
                  # 'netweights':training_return['network_weights']['policy']
              }  # {weight:[0.1 0.9],'objects': plist[]}
    pareto.put(ppoint)
        # end of training
    sampler_agent.end()
    trainer_tasks.put((parallel_util.END_SIGNAL, None))
    return training_return['network_weights']['policy'][0]

def main():
    parser = base_config.get_base_config()
    parser = mf_config.get_mf_config(parser)
    args = base_config.make_parser(parser)

   # if args.write_log:
    #    logger.set_file_handler(path=args.output_dir,
    #                            prefix='mf' + str(args.seed) + args.trust_region_method,
    #                            time_str=args.exp_id)

    # no random policy for model-free rl
    assert args.random_timesteps == 0

    print('Training starts at {}'.format(init_path.get_abs_base_dir()))
    from mbbl.trainer import shooting_trainer
    from mbbl.sampler import singletask_sampler
    from mbbl.worker import mf_worker
    import mbbl.network.policy.ppo_policy
    import mbbl.network.policy.ppo_policys


    policy_network = {
        'ppo': mbbl.network.policy.ppo_policy.policy_network,
        #'trpo': mbbl.network.policy.trpo_policy.policy_network,
        'sppo': mbbl.network.policy.ppo_policys.policy_network
    }[args.trust_region_method]

    # here the dynamics and reward are simply placeholders, which cannot be
    # called to pred next state or reward
    from mbbl.network.dynamics.base_dynamics import base_dynamics_network
    from mbbl.network.reward.groundtruth_reward import base_reward_network

    initweights=[]#[array([0.1, 0.9])]
    pareto=multiprocessing.Queue()
    parmrecord=[]
    pl=[]
    pertofront=[]
    if args.method == 'pfa':
        for value in range(8):
            objw = [0.1 + 0.1 * value, 0.9 - 0.1 * value]
            objw = np.around(objw, decimals=2)
            initweights.append(objw)
    else:
        for value in range(5):
            objw = [0.1 + 0.2 * value, 0.9 - 0.2 * value]
            objw = np.around(objw, decimals=2)
            initweights.append(objw)

    for objw in initweights:
        logger.set_file_handler(path=args.output_dir,
                               prefix=args.method  + str(args.seed) + args.trust_region_method + str(objw),
                              time_str=args.exp_id)
        theta=train(shooting_trainer, singletask_sampler, mf_worker,base_dynamics_network, policy_network, base_reward_network, objw,pareto,args,)
        parmrecord.append([objw,theta])

        #process =multiprocessing.Process(target=train,args=(shooting_trainer, singletask_sampler, mf_worker,
        #  base_dynamics_network, policy_network, base_reward_network, objw,pareto,args,))
        #process.start()
        #process.join()
        #record.append(process)

   # for process in record:

    for _ in range(pareto.qsize()):
        pl.append(pareto.get())

    #tf.compat.v1.reset_default_graph

    for l in range(len(pl)):
        for ll in range(len(pl[l]['objects'])):
            flag = 1
            if len(pertofront) == 0:
                flag = 0
                pertofront.append(np.concatenate((pl[l]['weight'],
                                                  pl[l]['objects'][ll], pl[l]['fitness'][ll],
                                                  pl[l]['hypervolume'])))
            else:
                for lenth in range(len(pertofront), 0, -1):
                    if pl[l]['objects'][ll][0] > pertofront[lenth - 1][2] \
                            and pl[l]['objects'][ll][1] > pertofront[lenth - 1][3]:
                        del pertofront[lenth - 1]
                    elif pl[l]['objects'][ll][0] <= pertofront[lenth - 1][2] \
                            and pl[l]['objects'][ll][1] <= pertofront[lenth - 1][3]:
                        flag = 0
                        break

            if flag:
                # hv = compute_hv(pl[l]['objects'][ll])
                pertofront.append(np.concatenate((pl[l]['weight'],
                                                  pl[l]['objects'][ll], pl[l]['fitness'][ll],
                                                  pl[l]['hypervolume']), axis=0))

               #pertoline.append(pl[l]['objects'][ll])
    pertofront.sort(key=lambda ppiont:ppiont[4],reverse=True)

    ''' self.epsilon *= args.eps_decay
        self.epsilon = max(self.epsilon, args.eps_min)
        q_value = self.predict(state)[0]
        if np.random.random() < self.epsilon:
            return random.randint(0, self.action_dim-1)
        return np.argmax(q_value)'''
    if args.method == 'cem':
        t = 0
        pl = []
        mean = 0
        cee = []
        var = 0.25
        epsilon = 0.95
        while t < 20 :
            if np.random.random() < epsilon:
                epsilon *= 0.9
                epsilon = max(epsilon, 0.0)
                while True:
                    obj1 = np.random.random()
                    obj1 = np.clip(obj1, 0.1, 0.9)
                    obj1 = np.around(obj1, decimals=2)
                    if obj1 not in cee:
                        break
                cem_weight = np.array([obj1, 1 - obj1])
                print('greed:', cem_weight)
            else:
                elites = np.array(pertofront)[0:20, 0]
                new_mean = np.mean(elites, axis=0)
                new_var = np.var(elites, axis=0)
                mean = 0.1 * mean + 0.9 * new_mean
                var = 0.1 * var + 0.9 * new_var#+0.0005
                if var < 0.001:
                    t+=1
                    continue
                cem_weight = generate_weights(mean, var, cee)
                print('cem', cem_weight)

            cee.append(cem_weight[0])
            #logger.set_file_handler(path=args.output_dir,
           #                     prefix=args.method + str(args.seed) + args.trust_region_method + str(cem_weight),
            #                    time_str=args.exp_id)

            #theta=train(shooting_trainer, singletask_sampler, mf_worker,base_dynamics_network, policy_network, base_reward_network,cem_weight,pareto,args,)
            best = pertofront[0][0:2]
            besttheta = parmrecord[0][1]
            for l in range(len(parmrecord)):
                if np.all(parmrecord[l][0] == best):
                    besttheta = parmrecord[l][1]
                    break
            retheta = re_train(besttheta, shooting_trainer, singletask_sampler,
                               mf_worker, base_dynamics_network, policy_network,
                               base_reward_network, cem_weight, pareto, args)
            parmrecord.append([cem_weight,retheta])
            for _ in range(pareto.qsize()):
                pl.append(pareto.get())

            for l in range(len(pl)):
                for ll in range(len(pl[l]['objects'])):
                    flag = 1
                    if len(pertofront) == 0:
                        flag = 0
                        pertofront.append(np.concatenate((pl[l]['weight'],
                                                          pl[l]['objects'][ll], pl[l]['fitness'][ll],
                                                          pl[l]['hypervolume'])))
                    else:
                        for lenth in range(len(pertofront), 0, -1):
                            if pl[l]['objects'][ll][0] > pertofront[lenth - 1][2] \
                                    and pl[l]['objects'][ll][1] > pertofront[lenth - 1][3]:
                                del pertofront[lenth - 1]
                            elif pl[l]['objects'][ll][0] <= pertofront[lenth - 1][2] \
                                    and pl[l]['objects'][ll][1] <= pertofront[lenth - 1][3]:
                                flag = 0
                                break

                    if flag:
                        # hv = compute_hv(pl[l]['objects'][ll])
                        pertofront.append(np.concatenate((pl[l]['weight'],
                                                          pl[l]['objects'][ll], pl[l]['fitness'][ll],
                                                          pl[l]['hypervolume']), axis=0))

            pertofront.sort(key=lambda ppiont:ppiont[4],reverse=True)
            #newfront=pertofront[0:100]
            t += 1
            print(t, epsilon, var)
        print(cee)

    ref=[0.,0.]
    data=np.array(pertofront)[0:,2:4]
    HV=HVCalculator.get_volume_from_array(data, ref)
    print('hypervolume = {:.0f}'.format(HV))
    os.makedirs(os.path.join('../result2/', args.method), exist_ok=True)
    #if args.cem:
    with open(os.path.join('../result2/', args.method, str(args.seed) + 're' + args.trust_region_method + args.exp_id + '.csv'), 'w') as fp:
        for index, value in enumerate(pertofront):
            fp.write(('{:.2f},'+'{:.2f},'+'{:.2f},'+'{:.2f},'+'{:.2f},'+'{:.2f},'+'\n').format(*(value)))
    fp.close()

if __name__ == '__main__':
    main()

