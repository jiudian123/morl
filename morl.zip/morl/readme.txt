主程序main文件夹下的两个main函数，其中moppo使用了参数重利用，作为完整的程序。mo没有，用作对比程序。
主要调参在mbbl.config中的base-config中。绘图程序在plot文件夹中。环境代码是mbbl.env
的insenv.py
